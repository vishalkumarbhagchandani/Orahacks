const { Client } = require("@elastic/elasticsearch");

const client = new Client({
  cloud: {
    id: "<YOUR CLOUD ID>",
  },
  auth: {
    username: "elastic",
    password: "<YOUR PASSWORD>",
  },
});

module.exports = client;
