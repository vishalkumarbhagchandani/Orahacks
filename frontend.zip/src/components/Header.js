import { useState } from "react";
import PropTypes from "prop-types";
import Toolbar from "@mui/material/Toolbar";
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";
import SearchIcon from "@mui/icons-material/Search";
import Typography from "@mui/material/Typography";
import Link from "@mui/material/Link";
import { NavLink } from "react-router-dom";
import PersonIcon from "@mui/icons-material/Person";
import { useAuth } from "../contexts/AuthContext";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import NotificationsIcon from "@mui/icons-material/Notifications";
import { useNavigate } from "react-router-dom";
import { Container } from "@mui/material";
import HomeIcon from "@mui/icons-material/Home";

function Header(rops) {
  const title = "Blog";
  const sections = [
    { title: "Academic Resources", url: "/topics/Academic Resources" },
    { title: "Career Services", url: "/topics/Career Services" },
    { title: "Campus Culture", url: "/topics/Campus Culture" },
    {
      title: "Local Community Resources",
      url: "/topics/Local Community Resources",
    },
    { title: "Social", url: "/topics/Social" },
    { title: "Sports", url: "/topics/Sports" },
    { title: "Health and Wellness", url: "/topics/Health and Wellness" },
    { title: "Technology", url: "/topics/Technology" },
    { title: "Travel", url: "/topics/Travel" },
    { title: "Alumni", url: "/topics/Alumni" },
  ];
  const { currentUser, signout } = useAuth();
  const navigate = useNavigate();

  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleLogout = () => {
    handleClose();
    signout();
  };

  return (
    <>
      <Container maxWidth="lg">
        <Toolbar sx={{ borderBottom: 1, borderColor: "divider" }}>
          <Typography
            component="h2"
            variant="h5"
            color="inherit"
            align="center"
            noWrap
            sx={{ flex: 1 }}
          >
            {title}
          </Typography>
          {!currentUser?.email && (
            <NavLink to="/signin">
              <Button variant="outlined" size="small">
                Sign in
              </Button>
            </NavLink>
          )}
          {currentUser?.email && (
            <div>
              <Button
                id="basic-button"
                aria-controls={open ? "basic-menu" : undefined}
                aria-haspopup="true"
                aria-expanded={open ? "true" : undefined}
                onClick={() => navigate("/")}
              >
                <HomeIcon />
              </Button>
              <Button
                id="basic-button"
                aria-controls={open ? "basic-menu" : undefined}
                aria-haspopup="true"
                aria-expanded={open ? "true" : undefined}
                onClick={handleClick}
              >
                <PersonIcon />
              </Button>
              <Button
                id="basic-button"
                aria-controls={open ? "basic-menu" : undefined}
                aria-haspopup="true"
                aria-expanded={open ? "true" : undefined}
                onClick={() => navigate("/notifications")}
              >
                <NotificationsIcon />
              </Button>
              <Menu
                id="basic-menu"
                anchorEl={anchorEl}
                open={open}
                onClose={handleClose}
                MenuListProps={{
                  "aria-labelledby": "basic-button",
                }}
              >
                <MenuItem onClick={handleClose}>
                  <NavLink
                    to="/create-post"
                    style={{ textDecoration: "none", color: "inherit" }}
                  >
                    Create Post
                  </NavLink>
                </MenuItem>
                {currentUser?.role === "administrator" && (
                  <MenuItem onClick={handleClose}>
                    <NavLink
                      to="/manage-profiles"
                      style={{ textDecoration: "none", color: "inherit" }}
                    >
                      Manage Profiles
                    </NavLink>
                  </MenuItem>
                )}
                <MenuItem onClick={handleLogout}>Logout</MenuItem>
              </Menu>
            </div>
          )}
        </Toolbar>
        <Toolbar
          component="nav"
          variant="dense"
          sx={{ justifyContent: "space-between", overflowX: "auto" }}
        >
          {sections.map((section, idx) => (
            <NavLink
              to={section.url}
              key={idx}
              style={{ color: "black", fontSize: "15px" }}
            >
              {section.title}
            </NavLink>
          ))}
        </Toolbar>
      </Container>
    </>
  );
}

export default Header;
